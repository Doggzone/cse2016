
public class SudokuPuzzle {

	public static void main(String[] args) {
		
		new SudokuController().playSudokuPuzzle();

	}
}
